<?php

// HTML Code For Form tag generator

?>
<style type="text/css">
#formoptions h4{margin-bottom:0;}
#seloptions .opttext, #seloptions .optprice{width:60%;}
#optionhtml {width:100%;}
</style>




